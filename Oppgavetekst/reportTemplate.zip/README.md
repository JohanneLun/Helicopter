# labreport
This repository contains a template for how lab reports or assignments can be written in LaTeX. It also contains some hints to useful packages for scientific writing in general. The template is intended for helicopter labs in the courses TTK4115 and TTK4135 at the Department of Engineering Cybernetics, NTNU.
